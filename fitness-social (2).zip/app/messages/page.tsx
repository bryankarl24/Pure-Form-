"use client"

import { MessagesPage } from "@/components/messages-page"

export default function MessagesPageWrapper() {
  return <MessagesPage />
}

